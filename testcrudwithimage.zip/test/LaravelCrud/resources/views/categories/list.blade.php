<!DOCTYPE html>
<html lang="en">
<head>
  <title>CRUD</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
 
</head>
<body>

<div class="container pt-5">
  <h2>Category<a class="btn btn-info " href="/category-create">Add Category</a></h2>   
  <table class="table">
    <thead>
      <tr>
        <th>sl no</th>
        <th>Title</th>
        <th>Image</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
     @foreach($categories as $category)
      <tr>
        <td>{{ $loop->index+1}}</td>
        <td>{{ $category->title}}</td>
        <td>{{ $category->image}} 
        <img width="100" height="100"  src="{{ asset('storage/images/'.$category->image) }}">

        <!-- <img src="{{asset('public/images/'.$category->image)}}"/> -->
      </td>
        
        <td>
            <a href="/category-edit/{{ $category->id }}" class="btn btn-sm btn-info">update</a>
            <a href="/category-delete/{{ $category->id }}" class="btn btn-sm btn-danger">delete</a>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>

</body>
</html>